const fs = require("fs");
const EventEmitter = require('events')

class TaskEmitter extends EventEmitter {

}
const taskEmitter = new TaskEmitter();

writeTask = (taskName, desc) => {
    var task = { taskName, desc }
    var tasks = []
  
    return new Promise(async function(resolve, reject){
        try {
            var data = await readTasks();
            tasks = data;
            
        } catch (err) {
            tasks = []            
        }
        tasks.push(task)
        fs.writeFile("task.json", JSON.stringify(tasks), (err) => {
            if(err) {
                reject(err)
                console.log("some err", err)
            } else {
                resolve(task)
                console.log("success")
            }
        })
    })
    
}
process.on("unhandledRejection", (err) => {
    console.log("Unexpected rject", err);
})
process.on("uncaughtException", (err) => {
    console.log("Unexpected error", err);
})
readTask = () => {
    return new Promise(function(resolve, reject) {
        fs.readFile("task.json", (err, data) => {
            if(err) {
                //reject(err);
                taskEmitter.emit("error", err);
            }else {
                resolve(JSON.parse(data));
                taskEmitter.emit("success", JSON.parse(data));
            }
        })
    })
    
}

module.exports = {
    writeTask, readTask, taskEmitter
}