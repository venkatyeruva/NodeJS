const yargs = require('yargs');
const fs = require('fs')
const tasks= require('./tasks')

yargs
    .command("add", "To add a new Task", () => {
        return yargs.options({
            tname: {
                describe: "The task name",
                demand: true,
                alias: "t"
            },
            desc: {
                describe: "The task description",
                demand: true,
                alias: "d"                
            }
        })
    })
    .command("list", "To list all taks")
    .help()

tasks.taskEmitter.on("success", (data)=> {
    data.forEach(item => {
            console.log(`Task Name: ${item.taskName}`);
            console.log(`Description: ${item.desc}`);
        })
    })

const command = process.argv[2]
var taskName = yargs.argv.tname;
var desc = yargs.argv.desc;

if(command === "add") {
    var task = {
        task: taskName,
        command: command,
        desc: desc
    }
    //fs.writeFileSync("tasks.json", task);
    tasks.writeTask(taskName, desc).then((result) => {
        console.log("file created")
    },(reject) => {
        console.log("file not created")
    });
    console.log("Task:", command, taskName);
    
} else if(command === "list") {
    tasks.readTask();
    // tasks.readTask().then((result) => {
    //     result.forEach(item => {
    //         console.log(item)
    //     });
    // },(reject) => {
    //     console.log(reject)
    // });
    console.log("Task list:", command, taskName);
} else {
    console.log("Unknown command")
}
