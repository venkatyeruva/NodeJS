const http = require('http');
const pid = process.pid;
var server = http.createServer();

server.on("request", (req, resp) => {
    for(let i=0; i<ie7; i++);
    resp.end(`Handled by process ${pid}`);
})

server.listen(8080, () => {
    console.log(`Started process ${pid}`);
})