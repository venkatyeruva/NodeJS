const http = require('http');
var server = http.createServer();

server.on("request", (req, res) => {
    console.log("Handling the request");
    res.writeHead(200,{'Content-Type': 'text/html'});
    res.write("<h1>Hello World!!!</h1>");
    res.end();
})
server.listen(8080, () => {
    console.log("Http Server started");
})