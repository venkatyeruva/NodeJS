const express = require('express');
const bodyParser = require('body-parser');
const app = express();

const http = require('http');
const socketIO = require('socket.io');
const httpServer = http.createServer(app);
const io = socketIO(httpServer);

const mongodb = require('mongodb');
const mongoClient = mongodb.MongoClient;

var allSockets = [];
var customers = [];

io.on("connection", (socket) => {
    allSockets.push(socket);
    console.log("Client Connected...");
    socket.emit("data", "Some data...");
    socket.on("disconnect", (socket) => {
        allSockets = [];
        console.log("Client disonnected...");
    })
})

function initData() {
    customers.push(
    { id: 1, name: "Google", location: "Bangalore"},
    { id: 2, name: "Google", location: "Bangalore"},
    { id: 3, name: "Google", location: "Bangalore"},
    { id: 4, name: "Google", location: "Bangalore"})
}
initData();

app.use(bodyParser.json());

app.use(express.static(__dirname + "/public"))

app.get("/", (req, res) => {
    res.status(200);
    res.write("Node Express REST API's");
    res.end();
})

app.post("/customers", (req, res) => {
    var customer = req.body;
    try {
        if (customer.id <= 0) {
            //Bad Request
            res.status(400);
            res.json(null);
        } else {
            customers.push(customer);
            mongoClient.connect("mongodb://localhost:27017", (err, client) => {
                if(err) {   
                    res.status(500);
                } else {
                    var db = client.db("BankDB");
                    db.collection("customers").insertOne(customer, (err, result) => {
                        if(err) {
                            resp.status(500);
                            res.json(null);
                        } else {
                            allSockets.forEach(socket => {
                                socket.emit("newCustomer", customer);
                            })
                            res.status(201);
                            res.json(null); 
                        }
                    })
                }
            });
        }
    } catch (error) {
        res.status(503);
        res.json(null);
    }
})

app.get("/customers", (req, res) => {
    res.json(customers);
})

app.get("/customers/:id", (req, res) => {
    var id = req.params.id;
    mongoClient.connect("mongodb://localhost:27017", (err, client) => {
        if(err) {
            res.status(500);
        } else {
            var db = client.db("BankDB");
            db.collection("customers").findOne({id: id}, (err, result) => {
                if(err) {
                    resp.status(500);
                    res.json(null);
                } else {                    
                    res.json(result);
                }
            })        
        }
    })
})

var port = process.env.PORT || 8090
httpServer.listen(port, () => {
    console.log("rest API server started")
})