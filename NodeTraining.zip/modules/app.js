const appModule = require('app_module')
const _ = require('lodash')
const os = require('os')
const fn = require('./functions').math

console.log(fn.add(6,10))
console.log(fn.subtract(6,10))