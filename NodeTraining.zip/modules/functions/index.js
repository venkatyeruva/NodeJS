function add (x, y) {
    return x + y;
}

function subtract (x, y) {
    return x - y;
}

module.exports.math = {
    add: add,
    subtract: subtract
}