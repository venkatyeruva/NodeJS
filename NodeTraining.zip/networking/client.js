const net = require('net');
const clientSocket = new net.Socket();
const readline = require('readline')
const os = require('os')

const readConsole = readline.createInterface({
    input: process.stdin,
    output: process.stdout
})
clientSocket.connect(9001, "localhost", () => {
    console.log("Connected to Server...");  
    clientSocket.setEncoding('utf-8');
    clientSocket.on("data", (data) => {
        console.log(data, os.userInfo().username)
       // clientSocket.write(data)
       readConsole.setPrompt("Enter any text to send, Ctrl+C to exist >> ")
       readConsole.prompt()
    })
    
    readConsole.on("line", (line) => {
        if(line === 'exit') {
            clientSocket.destroy()
            readConsole.close()
        } else {
            clientSocket.write(line)  
        }
        readConsole.prompt()

    })
});

process.on("uncaughtException", (err) => {
    console.log("Server not reachable...")
})