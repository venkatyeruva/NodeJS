const net = require('net');
const server = net.createServer();
const readline = require('readline')
const clientSocket = new net.Socket();
const allSockets = [];

var counter = 0;
server.on("connection", (socket) => {
    var clientId = ++counter;
    allSockets.push(socket)
    socket.setEncoding('utf-8')
    console.log("Request received");    
    socket.on("data", (data) => {
        console.log(data)
        allSockets.forEach((socketItem) => {
            socketItem.write(`${clientId} : ${data}`)
        })
    })
    socket.on("error", (data) => {
        console.log("Client Disconnected..")
    })
    
})

server.listen(9001, () => {
    console.log("server started at port 9001");
})

process.on("uncaughtException", (err) => {
    console.log("Server uncaughtException...", err)
})