var x= 4;
var y;

console.log("x=", x);
console.log("y=", y);
// Hoisting
function fn() {
    var x = 50;
    console.log("x=", x);
    if( x < 200) {
        var message = "Hello";
        //console.log("Let message", message);
    }
    console.log("message", message);
}
fn();
