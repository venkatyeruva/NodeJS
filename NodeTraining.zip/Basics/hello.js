console.log("Hello World!!!");
console.log(process.pid)
var x = 10;
console.log("x=", x);
console.log("global x=", global.x);

y = 10;
console.log("y=", y);
console.log("global y=", global.y);