function someTask(arg) {
    // long-runningtask
    console.log("starting");
    return new Promise(function(resolve, reject){
        console.log("promise");
        if(arg > 50) {
            setTimeout(() => {
                var result = arg * 2
                resolve(result);
            }, 2000)
        } else {
            setTimeout(() => {
                var result = arg * 5
                reject(result);
            }, 2000)
        }
    })    
}
const invokeSomefn = async () => {
    try {
        var result = await someTask(150);
        console.log("result :", result);
    } catch (err) {
        console.log("err: ", err);
    }
}
invokeSomefn();



// Promise
//     .all([Promise.reject("A"), Promise.reject("B"), someTask(10)])
//     .then((result) => {
//         console.log("All Resolved:", result)
//     },(result) => {
//         console.log("All Rejected:", result)
//     })


// var handle = someTask("300");
// handle.then((success) => {
//     console.log(success)
// }, (failure) => {
//     console.log(failure)
// });
console.log("Finishing");