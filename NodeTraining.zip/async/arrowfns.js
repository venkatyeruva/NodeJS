function sum(x,y) {
    console.log(arguments)
    console.log("in summ");
}

sum(2,3);
sum();
sum(2,3,4,5,6);

// function expression
var add = function(a, b) {
    return a+b;
}
console.log(add(56, 8))

//arrow function
add = (a, b) => a + b;
console.log(add(7, 8))

suare = a => a*a
console.log(suare(7))

var obj = {
    id: 100,
    print: function() { 
        var _this = this       
        console.log("Id: ", this.id)
        setTimeout(function() {
            console.log(_this.id)
        },100)
    }
}
obj.print()