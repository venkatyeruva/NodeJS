console.log("Starting app...");

setTimeout(function(){
    console.log("executing app 100...");
}, 100)

setTimeout(function(){
    console.log("executing app at 0...");
}, 0)

function process(callback) {
    console.log("In process...");
    callback();
    console.log("Process completed")
}

process(function() {
    console.log("process callback");
})

console.log("Finishing app...")